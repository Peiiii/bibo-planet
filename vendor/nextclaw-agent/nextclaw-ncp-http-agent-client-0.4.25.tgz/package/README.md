# @nextclaw/ncp-http-agent-client

HTTP/SSE transport adapter implementing `NcpAgentClientEndpoint` for agent scenarios.

## Build

```bash
pnpm -C packages/ncp-packages/nextclaw-ncp-http-agent-client build
```

## API

- `new NcpHttpAgentClientEndpoint(options)`
